package cn.itheima.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;

import cn.itheima.dao.LinkManDao;
import cn.itheima.domain.Customer;
import cn.itheima.domain.LinkMan;
import cn.itheima.utils.HibernateUtils;

public class LinkManDaoImpl implements LinkManDao {

	public void save(LinkMan lm) {
		//1 获得session
		Session session = HibernateUtils.getCurrentSession();
		session.save(lm);
	}

	public List<LinkMan> getAll() {
		//1 获得session
		Session session = HibernateUtils.getCurrentSession();
		//2 创建Criteria对象
		Criteria c = session.createCriteria(LinkMan.class);
		return c.list();
	}

	public List<LinkMan> getAll(DetachedCriteria dc) {
		//1 获得session
		Session session = HibernateUtils.getCurrentSession();
//2 将离线对象关联到session
		Criteria c = dc.getExecutableCriteria(session);
//3 执行查询并返回
return c.list();
	}

}
