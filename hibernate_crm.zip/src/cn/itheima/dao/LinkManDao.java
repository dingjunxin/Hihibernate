package cn.itheima.dao;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;

import cn.itheima.domain.LinkMan;

public interface LinkManDao {
	//保存联系人
	void save(LinkMan lm);
	//查询所有客户
	List<LinkMan> getAll();
	//根据条件查询所有客户
	List<LinkMan> getAll(DetachedCriteria dc);
}
